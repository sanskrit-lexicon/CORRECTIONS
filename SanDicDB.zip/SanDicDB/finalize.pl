use strict;

use DBI;

my $dbh = DBI->connect("dbi:SQLite:dbname=sandic.db", undef, undef, 
                       {'RaiseError'     => 1,
                        'sqlite_unicode' => 1}) or die $DBI::errstr; 

$dbh->do("PRAGMA synchronous = OFF");
$dbh->do("PRAGMA temp_store  = MEMORY");

$dbh->do("INSERT INTO dictStats (origin, recs, words) 
            SELECT '-',  
               (SELECT count(word) FROM dictEntries), 
               (SELECT count(DISTINCT(word)) FROM dictEntries)");
             
$dbh->do("INSERT INTO dictStats (origin, recs, words) 
            SELECT name,
               (SELECT count(word) FROM dictEntries WHERE origin LIKE t.name),
               (SELECT count(DISTINCT(word)) FROM dictEntries WHERE origin LIKE t.name)
            FROM dictOrigins t");