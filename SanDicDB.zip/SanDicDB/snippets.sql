--Поиск дубликатов   
SELECT word, hom, origin, count() FROM dictEntries GROUP BY word, hom, origin HAVING count() > 1

SELECT * FROM dictEntries WHERE hom > '0'
SELECT count() FROM dictEntries
SELECT count(DISTINCT(word)) FROM dictEntries
SELECT count(DISTINCT(word)) FROM dictEntries WHERE origin LIKE 'Macdonell'

SELECT substr(word, 1, 1), count() FROM (SELECT DISTINCT word FROM dictEntries) GROUP BY substr(word, 1, 1) ORDER BY 1 ASC

SELECT name,
   (SELECT count(word) FROM dictEntries WHERE origin LIKE t.name),
   (SELECT count(DISTINCT(word)) FROM dictEntries WHERE origin LIKE t.name)
FROM dictOrigins t

SELECT short, author, name, records, words FROM statistics t1 LEFT OUTER JOIN origins t2 ON t1.id = t2.id

SELECT name, author, desc, lang, words,
   (SELECT words FROM dictStats WHERE origin = '-')
FROM dictOrigins INNER JOIN dictStats ON name = origin