﻿use strict;

use DBI;

my $dbh = DBI->connect("dbi:SQLite:dbname=:memory:", undef, undef, 
                       {'RaiseError'     => 1,
                        'sqlite_unicode' => 1}) or die $DBI::errstr; 

$dbh->do("PRAGMA synchronous = OFF");
$dbh->do("PRAGMA temp_store  = MEMORY");

open(IN,  "<:encoding(cp1251)", "yukta_local") or die;
open(OUT, ">:utf8", "yukta.txt") or die;

my $t = undef;

while (<IN>) {
    chomp;
    
    next if /^--/;
    next if /^\s*$/;
    
    next unless /(CREATE TABLE|INSERT INTO) (mw|gr|er) / || $t;
    
    if (/CREATE TABLE/) {
      $t = $_;
    } elsif ($t) {
    
      if (/\).*;/) {
         $t =~ s/auto_increment//;
         $t =~ s/UNIQUE KEY.+//;
         $t =~ s/PRIMARY KEY.+//;
         $t =~ s/KEY.+//;
         1 while $t =~ s/,\s+$//;
         
         $dbh->do("$t);");
         
         $t = undef;
      } else {
         $t .= $_;
      }
      
    } else {
      s/\\'/''/g;

      $dbh->do("$_");
    }
}

# my $c = 0;          

my (%ents, $word, $hom, $desc);

foreach (@{$dbh->selectall_arrayref("SELECT sans, lst_gr FROM mw")}) {
   $word = $_->[0];

   foreach (@{$dbh->selectall_arrayref("SELECT gr, lst_er FROM gr WHERE " . suff("gr_ind", $_->[1]))}) {
      my $gr = $_->[0];

      my @rec;
      
      if ($_->[1]) {
         foreach (@{$dbh->selectall_arrayref("SELECT rus, src FROM er WHERE " . suff("ecod", $_->[1]))}) {
            # my $rus = $_->[0];
            # my $src = $_->[1];
            
            push(@rec, [$gr, @{$_}]);
         }
      } else {
         push(@rec, [$gr]);
      }
      
     push(@{$ents{$word}}, \@rec);
   }
   
   #last if ++$c >= 50;
}

foreach my $word (keys %ents) {
   $hom = 0;
   
   print OUT "KEY: $word\n";
   
   foreach (@{$ents{$word}}) {
      foreach (@{$_}) {
         print OUT "HOM: $hom\n$_->[0] $_->[1] $_->[2]\n";
      }
   
      $hom++;
   }
   
   print OUT "\n";
}

sub suff { return " $_[0] = " . join(" OR $_[0] = ", split(';', $_[1])) }
