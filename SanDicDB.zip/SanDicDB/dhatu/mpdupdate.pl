﻿use strict;

use DBI;

my $dbh = DBI->connect("dbi:SQLite:dbname=sandic.db", undef, undef, 
                       {'RaiseError'     => 1,
                        'sqlite_unicode' => 1}) or die $DBI::errstr; 

$dbh->do("PRAGMA synchronous = OFF");
$dbh->do("PRAGMA temp_store  = MEMORY");


$dbh->do("DELETE FROM dictAbbs WHERE origin = 'Dhātu-pāṭha'");
$dbh->do("DELETE FROM dictEntries WHERE origin = 'Dhātu-pāṭha'");
$dbh->do("DELETE FROM dictOrigins WHERE name = 'Dhātu-pāṭha'");
$dbh->do("DELETE FROM dictStats");


my @sth = ($dbh->prepare("INSERT INTO dictOrigins (name, author, desc, uri, lang) VALUES (?, ?, ?, ?, ?)"),
           $dbh->prepare("INSERT INTO dictAbbs (abb, desc, origin) VALUES (?, ?, ?)"), 
           $dbh->prepare("INSERT INTO dictEntries (word, hom, desc, origin) VALUES (?, ?, ?, ?)"));

open(IN, "<:utf8", "origin.txt") or die;
my @origin = split('#', <IN>);

$sth[0]->execute(@origin);

open(IN, "<:utf8", "abbreviations.txt") or die;

while (<IN>) {
   chomp;
   next if /^\s*$/;

   $sth[1]->execute(split(' = '), $origin[0]);
}

open(IN, "<:utf8", "dhatu.ready.txt") or die;

my (%ents, $rec, $word, $hom);

while (<IN>) {
   chomp;
   next if /^\s*$/;
   
   if (/^KEY:\s+(.+)/) {
      push(@{$ents{$word}}, $rec) if $word;
      $word = $1;
      $rec = []; 
      $hom = undef;
   } elsif (/^HOM:\s+(.+)/) {
      $hom = $1;
   } else {
      push (@{$rec->[$hom]}, $_);
   }
}

push(@{$ents{$word}}, $rec); # последняя запись

foreach my $word (keys %ents) {
   # print "word: $word\n";

   $hom = 0;

   foreach (@{$ents{$word}}) { # rec
      foreach (@{$_}) {
         next unless $_; # если hom начинался не с 0
         $sth[2]->execute($word, $hom, join("\n\n", @{$_}) , $origin[0]);
         $hom++;
      }
   }
}


$dbh->do("INSERT INTO dictStats (origin, recs, words) 
            SELECT '-',  
               (SELECT count(word) FROM dictEntries), 
               (SELECT count(DISTINCT(word)) FROM dictEntries)");
             
$dbh->do("INSERT INTO dictStats (origin, recs, words) 
            SELECT name,
               (SELECT count(word) FROM dictEntries WHERE origin LIKE t.name),
               (SELECT count(DISTINCT(word)) FROM dictEntries WHERE origin LIKE t.name)
            FROM dictOrigins t");