use utf8;

use strict;

open(IN,  "<:utf8", "monier.txt") or die;
open(OUT, ">:utf8", "monier.ready.txt") or die;

my $c = 0;

while (<IN>) {
    chomp;

    my ($id, $hom, $text);
    
    ($id) = /<key1>(.*?)ः?<\/key1>/;
    
    $hom = /<h>.*<hom>(.*?)\.?<\/hom>.*<\/h>/ ? $1 : 0;

    ($text) = /<body>(.*)<\/body>/;

    $text =~ s/््/्/g;
    
    $text =~ s/_|~/ /g;
    $text =~ s/<.+?>/ /g;
    
    $text =~ s/^\s+//g;
    $text =~ s/\s+$//g;

    $text =~ s/(\x{221a})\s+/$1/g; # квадратный корень
    
    1 while ($text =~ s/(\s{2,})/ /g);
   
    $text =~ s/\s+(,|;)/$1/g;
    $text =~ s/(\(|\[)\s+/$1/g;
    $text =~ s/\s+(\)|\])/$1/g;
     
    $text =~ s/"\s+(.+?)\s+"/"$1"/g;

    print OUT "KEY: $id\nHOM: $hom\n$text\n\n";

    #last if $c++ == 1000;
}