use utf8;
use strict;

open(IN,  "<:utf8", "apte.txt") or die;
open(OUT, ">:utf8", "apte.ready.txt") or die;

my (@record, $id, $hom, $text, $c);

while (<IN>) {
   chomp;
   
   s/\$/ऽ/g;
   
   if (/\s*ID:\s+(.+)/) {
      $id = $1;
      $hom = 0;
      @record = ();
   } elsif (/^\s*$/) {
      add();
      flush();
   } elsif (/^HOM:/) {
      add();

      $hom++ unless /-\s*(\d+)/;
      
      if (/\p{Devanagari}/) {
         s/^HOM:\s*//;
         s/-?-\s*(\d+)$//;
         s/\s(\d+)$//;
         s/^-(\d+)\s//;
         s/-//g;

         $text = "$_ ";
      }
      
   } else {
      $text .= $_;
   }

   #last if ++$c == 300;
}

sub add {
   $text =~ s/^\s*//;
   $text =~ s/\s*$//;
   $text =~ s/\n/ /g;
   
   $text =~ s/--//g;
   $text =~ s/:-/:/g;
   $text =~ s/\s+:/:/g;
   
   $text =~ s/q\. v;/q\. v\.;/g;
   $text =~ s/e\. g(\s|;)/e\. g\.($1)/g;

   $text =~ s/&c([^\.])/&c\.$1/g;
   
   $text =~ s/([a-z])-\s+([A-za-z])/$1$2/g; # убираем перенос в словах
   
   1 while ($text =~ s/(\s{2,})/ /);

   push(@{$record[$hom]}, $text) unless $text =~ /^\s*$/;
   $text = undef;
}

sub flush {
   $id =~ s/^\s*//;
   $id =~ s/_/ /g;
   $id =~ s/([^\p{Devanagari}\s]+)/[$1]/g;
   
   my ($key) = ($id =~ /(\p{Devanagari}+)/);

   $record[0][0] =~ s/^\s*$key\s*//;
   $record[0][0] = "$id, " . $record[0][0];

   if (@record == 2) {
      # HOM: 0
      # HOM: 1
      # HOM: 1
      push(@{$record[0]}, splice(@{$record[1]}));
   } elsif (@record > 2) {
      # HOM: 0
      # HOM: 1
      # HOM: 2
      # HOM: ..
      unshift(@{$record[1]}, splice(@{$record[0]}));
   }
   
   $key =~ s/ः$//;
   
   print OUT "KEY: $key\n";
   
   for (my $hom = 0; $hom < @record; $hom++) {
      for (my $des = 0; $des < @{$record[$hom]}; $des++) {
         print OUT "HOM: $hom\n$record[$hom][$des]\n";
      }
   }
   
   print OUT "\n";
}

