use utf8;
use strict;

open(OUT, ">:utf8", "apte.txt") or die;

my ($num, $subnum);

foreach my $subdir (0 .. 6) {    
   opendir(DIR, "txt/$subdir") or die;

   my @fnum = map { /(\d+).html.txt/ } readdir(DIR);

   foreach (sort { $a <=> $b } @fnum) {
      my $txt = "page_" . $subdir . "_$_.html.txt";
      
      open(IN, "<:utf8", "txt/$subdir/$txt") or die;

      while (<IN>) {
         chomp;
         
         next if /^\s*$/;

         s/------------//;
         
         if (/^ID:/) {
            s/<|>//g; 

            print OUT "\n"
         }
         
         print OUT "$_\n";
      }
   }
}

