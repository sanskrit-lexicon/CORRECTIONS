use LWP::UserAgent;
use HTML::LinkExtor;

use strict;

my $num = 7;

# page 001 == 7
my $url = "/cgi-bin/romadict.pl?page=7&table=macdonell&display=utf8";

my $ua   = LWP::UserAgent->new();
my $h    = HTTP::Headers->new(Content_Type => 'text/html, text/plain');
my $lext = HTML::LinkExtor->new(\&cb);

while (1) {
   my $req = HTTP::Request->new('GET', "http://dsal.uchicago.edu/$url", $h);

   my $res = $ua->request($req);

   $res->is_success or die "$url: " . $res->message;

   print "url: $url\n";

   my $file = "mirror/page_$num.html";
   
   open(FH, "> $file") or die "Can't open file";

   print FH $res->content;

   my $tmp = $num;
   
   $lext->parse_file($file);
   
   last if ($tmp == $num);
}

sub cb {
   my($tag, %links) = @_;
     
   return if $tag eq 'img';

   foreach (keys %links) {
      next unless $links{$_} =~ /display=utf8/;
   
      $links{$_} =~ /&page=(\d+)&/;

      ($num, $url) = ($1, $links{$_}) if ($1 > $num);
   }  
 }