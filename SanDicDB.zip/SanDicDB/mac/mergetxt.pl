use utf8;

use strict;

my %words;

open(OUT, ">:utf8", "macdonell.txt") or die;

for my $page (7 .. 189) {
   open(IN, "<:utf8", "txt/page_$page.html.txt") or die;
   
   my $start;

   while (<IN>) {
      chomp;
      
      next if /^\s*$/;
      
      # 10 страница не начинается с First|Previous
      if (/^(First|Previous)/ || $page == 10) {
         $start = !$start;
         next;
      }
      
      next unless $start;
      
      /^(.+?)\s/;
      $words{$1}++;

      # print "Error: $page -> $_\n" unless /^\p{Devanagari}/;
      
      print OUT "$_\n";
   }
}

open(WL, ">:utf8", "wordlist.txt") or die;

foreach (sort keys %words) {
   print WL "$_ $words{$_}\n" if $words{$_} > 1;
}